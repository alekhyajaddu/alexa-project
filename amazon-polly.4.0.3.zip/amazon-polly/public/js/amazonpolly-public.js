/**
 * Additional JS if needed.
 *
 * @link       amazon.com
 * @since      1.0.0
 *
 * @package    Amazonpolly
 */

(function( $ ) {
	'use strict';

	$( document ).ready(
		function(){

		}
	);

})( jQuery );
